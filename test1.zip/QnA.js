/**
 * http://usejsdoc.org/
 */

module.exports= class QnA{
	constructor(QnAquery, PlayerList){
		this.query = QnAquery;
		this.PlayerList = PlayerList;
	}
	
	say(){
		return this.query;
	}
}
