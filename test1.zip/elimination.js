/**
 * http://usejsdoc.org/
 */

module.exports= class elimination{
	constructor(query, PlayerList){
		this.query = query;
		this.PlayerList = PlayerList;
	}
	
	say(){
		return this.query;
	}
	
	eliminate(eliminater, eliminatee){
		
		
		if(eliminatee.role == "king"){
			eliminatee.isAlive = 0;
			return PlayerList
		}
		else {
			eliminater.isAlive = 0;
			return PlayerList
		}
	}
}

